package com.kashish.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.media.AudioManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.PhoneNumberUtils
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern

class KashishAccessibilityService : AccessibilityService() {
    companion object { var instance: KashishAccessibilityService? = null }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun handleCommand(raw: String) {
        val cmd = raw.lowercase(Locale.getDefault()).trim()
        when {
            cmd == "home" || cmd.contains("home") || cmd.contains("होम") -> { performGlobalAction(GLOBAL_ACTION_HOME); say("Home खोल दिया") }
            cmd == "back" || cmd.contains("back") || cmd.contains("वापस") || cmd.contains("पीछे") -> { performGlobalAction(GLOBAL_ACTION_BACK); say("वापस") }
            cmd.contains("recent") || cmd.contains("हाल के") -> { performGlobalAction(GLOBAL_ACTION_RECENTS); say("Recent apps") }
            cmd.contains("notification") || cmd.contains("नोटिफिकेशन") -> { performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); say("Notifications") }
            cmd.contains("quick settings") || cmd.contains("क्विक सेटिंग") -> { performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS); say("Quick settings") }
            cmd.contains("lock") || cmd.contains("लॉक") -> if (Build.VERSION.SDK_INT >= 28) { performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN); say("Phone lock कर दिया") }
            cmd.contains("scroll down") || cmd.contains("नीचे स्क्रॉल") || cmd.contains("नीचे करो") -> swipe(true)
            cmd.contains("scroll up") || cmd.contains("ऊपर स्क्रॉल") || cmd.contains("ऊपर करो") -> swipe(false)
            cmd.contains("volume up") || cmd.contains("आवाज़ बढ़") || cmd.contains("वॉल्यूम बढ़") -> adjustVolume(AudioManager.ADJUST_RAISE)
            cmd.contains("volume down") || cmd.contains("आवाज़ कम") || cmd.contains("वॉल्यूम कम") -> adjustVolume(AudioManager.ADJUST_LOWER)
            cmd.contains("mute") || cmd.contains("म्यूट") -> adjustVolume(AudioManager.ADJUST_MUTE)
            cmd.contains("unmute") || cmd.contains("अनम्यूट") -> adjustVolume(AudioManager.ADJUST_UNMUTE)
            cmd.contains("play") || cmd.contains("music play") || cmd.contains("गाना चल") -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
            cmd.contains("pause") || cmd.contains("music pause") || cmd.contains("रोक") -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
            cmd.contains("next song") || cmd.contains("next track") || cmd.contains("अगला गाना") -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            cmd.contains("previous song") || cmd.contains("पिछला गाना") -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            cmd.contains("flashlight on") || cmd.contains("torch on") || cmd.contains("टॉर्च चालू") -> flashlight(true)
            cmd.contains("flashlight off") || cmd.contains("torch off") || cmd.contains("टॉर्च बंद") -> flashlight(false)
            cmd.contains("screenshot") || cmd.contains("screen shot") || cmd.contains("स्क्रीनशॉट") -> takeScreenshot()
            cmd.contains("brightness") || cmd.contains("ब्राइटनेस") -> setBrightnessFromCommand(cmd)
            cmd.contains("open youtube") || cmd.contains("youtube खोल") -> openPackageByLabel("youtube", "com.google.android.youtube")
            cmd.contains("open whatsapp") || cmd.contains("whatsapp खोल") -> openPackageByLabel("whatsapp", "com.whatsapp")
            cmd.contains("open chrome") || cmd.contains("chrome खोल") -> openPackageByLabel("chrome", "com.android.chrome")
            cmd.contains("open settings") || cmd.contains("settings खोल") || cmd.contains("सेटिंग खोल") -> startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            cmd.startsWith("call ") || cmd.startsWith("कॉल ") || cmd.contains("call me") || cmd.contains("फोन करो") || cmd.contains("कॉल करो") -> callNumber(extractPhone(cmd))
            cmd.contains("sms") || cmd.contains("message") || cmd.contains("मैसेज") || cmd.contains("संदेश") -> sendSmsCommand(cmd)
            cmd.contains("whatsapp") && (cmd.contains("message") || cmd.contains("msg") || cmd.contains("मैसेज")) -> sendWhatsAppCommand(cmd)
            else -> openAnyInstalledApp(cmd)
        }
    }

    private fun extractPhone(text: String): String? {
        val digits = Pattern.compile("[+]?\\d[\\d ()-]{8,}").matcher(text)
        if (digits.find()) return PhoneNumberUtils.normalizeNumber(digits.group().replace(" ", ""))
        return null
    }

    private fun callNumber(number: String?) {
        if (number.isNullOrBlank()) { say("कृपया phone number बोलिए"); return }
        startActivity(Intent(Intent.ACTION_DIAL).apply { data = android.net.Uri.parse("tel:$number"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        say("Dialer खोल दिया")
    }

    private fun sendSmsCommand(cmd: String) {
        val number = extractPhone(cmd)
        if (number.isNullOrBlank()) { say("SMS के लिए phone number बोलिए"); return }
        val message = cmd.substringAfter(number, "").trim().removePrefix("message").removePrefix("msg").removePrefix("मैसेज").trim()
        startActivity(Intent(Intent.ACTION_SENDTO).apply { data = android.net.Uri.parse("smsto:$number"); putExtra("sms_body", message); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
        say("SMS तैयार है, Send दबाइए")
    }

    private fun sendWhatsAppCommand(cmd: String) {
        val number = extractPhone(cmd)
        if (number.isNullOrBlank()) { say("WhatsApp के लिए phone number बोलिए"); return }
        val message = cmd.substringAfter(number, "").replace("whatsapp", "").replace("message", "").replace("msg", "").replace("मैसेज", "").trim()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; setPackage("com.whatsapp"); putExtra(Intent.EXTRA_TEXT, message); putExtra("jid", number.replace("+", "") + "@s.whatsapp.net"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent); say("WhatsApp message तैयार है") } catch (_: Exception) { say("WhatsApp installed नहीं है") }
    }

    private fun openAnyInstalledApp(cmd: String) {
        val wanted = cmd.removePrefix("open ").removePrefix("खोलो ").removePrefix("खोल ").trim()
        if (wanted.isBlank()) { say("कौन सा app खोलना है?"); return }
        val apps = packageManager.getInstalledApplications(0)
        val match = apps.firstOrNull { packageManager.getApplicationLabel(it).toString().lowercase(Locale.getDefault()).contains(wanted) }
        if (match != null) { packageManager.getLaunchIntentForPackage(match.packageName)?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it); say("App खोल दिया") } ?: say("App नहीं खुल सका") }
        else say("यह app नहीं मिला")
    }

    private fun openPackageByLabel(label: String, pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(intent); say("$label खोल दिया") } else say("$label installed नहीं है")
    }

    private fun adjustVolume(direction: Int) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.adjustVolume(direction, AudioManager.FLAG_SHOW_UI)
        say("Volume बदल दिया")
    }

    private fun mediaKey(code: Int) {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        say("Music control")
    }

    private fun setBrightnessFromCommand(cmd: String) {
        val match = Pattern.compile("(\\d{1,3})").matcher(cmd)
        val percent = if (match.find()) match.group(1).toIntOrNull()?.coerceIn(1, 100) else 50
        if (Build.VERSION.SDK_INT >= 23 && !Settings.System.canWrite(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); say("Brightness permission दें, फिर command बोलिए"); return
        }
        try { Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, (255 * percent / 100)); say("Brightness $percent percent") } catch (_: Exception) { say("Brightness change नहीं हो सका") }
    }

    private fun takeScreenshot() {
        if (Build.VERSION.SDK_INT < 30) { say("Screenshot voice feature Android 11 या उससे ऊपर चाहिए"); return }
        takeScreenshot(android.view.Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) { saveScreenshot(result.hardwareBuffer, result.colorSpace); result.hardwareBuffer.close() }
            override fun onFailure(errorCode: Int) { say("Screenshot नहीं बन सका") }
        })
    }

    private fun saveScreenshot(buffer: android.hardware.HardwareBuffer, colorSpace: android.graphics.ColorSpace?) {
        val bitmap = Bitmap.wrapHardwareBuffer(buffer, colorSpace) ?: run { say("Screenshot नहीं बन सका"); return }
        val name = "Kashish_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".png"
        val values = android.content.ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name); put(MediaStore.Images.Media.MIME_TYPE, "image/png"); put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Kashish")
        }
        contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)?.let { uri -> contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        bitmap.recycle(); say("Screenshot save हो गया")
    }

    private fun swipe(down: Boolean) {
        if (Build.VERSION.SDK_INT < 24) return
        val path = Path(); val x = resources.displayMetrics.widthPixels / 2f
        if (down) { path.moveTo(x, 500f); path.lineTo(x, 1400f) } else { path.moveTo(x, 1400f); path.lineTo(x, 500f) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 500)).build(), null, null)
    }

    private fun flashlight(on: Boolean) {
        val manager = getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        try { val id = manager.cameraIdList.firstOrNull { manager.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }; if (id != null) manager.setTorchMode(id, on); say(if (on) "Torch on" else "Torch off") } catch (_: Exception) { say("Torch control unavailable") }
    }

    private fun say(text: String) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show() }
    override fun onDestroy() { instance = null; super.onDestroy() }
}
