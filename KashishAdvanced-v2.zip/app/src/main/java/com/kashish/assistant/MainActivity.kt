package com.kashish.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        requestNeededPermissions()
        buildUi()
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        if (Build.VERSION.SDK_INT >= 31) permissions += Manifest.permission.BLUETOOTH_CONNECT
        val missing = permissions.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 10)
    }

    private fun buildUi() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 60, 40, 40)
        }
        val title = TextView(this).apply { text = "✨ Kashish"; textSize = 34f; gravity = Gravity.CENTER }
        val info = TextView(this).apply {
            text = "Hindi + English Voice Assistant\n\nExamples:\n• Hey Kashish, open YouTube\n• Kashish, call 9876543210\n• WhatsApp message to 9876543210 hello\n• volume up / brightness 50%\n• screenshot / scroll down / play music"
            textSize = 17f; gravity = Gravity.CENTER; setPadding(0, 30, 0, 30)
        }
        status = TextView(this).apply { text = "Ready"; textSize = 16f; gravity = Gravity.CENTER }
        val listen = Button(this).apply { text = "🎙️ बोलकर Command दें"; setOnClickListener { startListening() } }
        val wake = Button(this).apply { text = "🟢 Hey Kashish Wake Mode ON"; setOnClickListener { startWakeMode() } }
        val stopWake = Button(this).apply { text = "🔴 Wake Mode OFF"; setOnClickListener { stopService(Intent(this@MainActivity, WakeWordService::class.java)) } }
        val access = Button(this).apply { text = "♿ Accessibility ON करें"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val write = Button(this).apply { text = "☀️ Brightness Permission"; setOnClickListener { openWriteSettings() } }
        box.addView(title); box.addView(info); box.addView(status); box.addView(listen); box.addView(wake); box.addView(stopWake); box.addView(access); box.addView(write)
        setContentView(box)
    }

    private fun startWakeMode() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11); return
        }
        val intent = Intent(this, WakeWordService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "Hey Kashish wake mode started"
        speak("Hey Kashish wake mode चालू है")
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Speech recognition उपलब्ध नहीं है."; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "सुन रहा हूँ…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Command process हो रही है…" }
                override fun onError(error: Int) { status.text = "Voice error: $error" }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    status.text = "आपने कहा: $text"
                    KashishAccessibilityService.instance?.handleCommand(text)
                        ?: run { status.text = "Accessibility Service ON करें"; speak("पहले Accessibility Service चालू करें") }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Hey Kashish को command दें")
        }
        recognizer?.startListening(intent)
    }

    private fun openWriteSettings() {
        if (Build.VERSION.SDK_INT >= 23) startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kashish")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        recognizer?.destroy(); tts?.shutdown(); super.onDestroy()
    }
}
