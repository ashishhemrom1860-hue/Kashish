package com.kashish.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

class WakeWordService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var running = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification: Notification = NotificationCompat.Builder(this, "kashish_voice")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Kashish is listening")
            .setContentText("Say: Hey Kashish + your command")
            .setOngoing(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1001, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else startForeground(1001, notification)
        tts = TextToSpeech(this, this)
        running = true
        listenForWakeWord()
    }

    private fun listenForWakeWord() {
        if (!running || !SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { if (running) android.os.Handler(mainLooper).postDelayed({ listenForWakeWord() }, 700) }
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    val normalized = heard.lowercase(Locale.getDefault()).trim()
                    val wake = normalized.contains("hey kashish") || normalized.contains("hey kashis") || normalized.contains("हे कशिश") || normalized.contains("हे काशिश") || normalized.contains("काशिश")
                    if (wake) {
                        val command = normalized.substringAfter("hey kashish", "").trim()
                            .ifBlank { normalized.substringAfter("काशिश", "").trim() }
                        if (command.isNotBlank()) {
                            KashishAccessibilityService.instance?.handleCommand(command)
                        } else speak("जी, बोलिए")
                    }
                    if (running) android.os.Handler(mainLooper).postDelayed({ listenForWakeWord() }, 350)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kashish") }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("kashish_voice", "Kashish Voice", NotificationManager.IMPORTANCE_LOW))
        }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { running = false; recognizer?.destroy(); tts?.shutdown(); super.onDestroy() }
}
