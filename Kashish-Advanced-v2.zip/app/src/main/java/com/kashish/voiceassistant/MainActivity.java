package com.kashish.voiceassistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.BatteryManager;
import android.content.Context;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int AUDIO_PERMISSION = 100;
    private TextView status, chat;
    private EditText input;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean hindi = true;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(hindi ? new Locale("hi","IN") : Locale.US);
        });
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle b){ status.setText("सुन रही हूँ…"); }
                public void onBeginningOfSpeech(){}
                public void onRmsChanged(float f){}
                public void onBufferReceived(byte[] b){}
                public void onEndOfSpeech(){status.setText("समझ रही हूँ…");}
                public void onError(int e){status.setText("फिर से कोशिश करें");}
                public void onResults(Bundle b){
                    ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if(a!=null&&!a.isEmpty()){input.setText(a.get(0)); runCommand(a.get(0));}
                    status.setText("तैयार");
                }
                public void onPartialResults(Bundle b){}
                public void onEvent(int e,Bundle b){}
            });
        }
        screen();
    }

    private void screen() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,18);
        root.setBackgroundColor(0xFFF5F1FA);
        TextView title=new TextView(this); title.setText("✦ KASHISH AI"); title.setTextSize(26); title.setTextColor(0xFF6A35A0); title.setGravity(17); title.setPadding(0,12,0,4); root.addView(title);
        TextView sub=new TextView(this); sub.setText("Your personal voice assistant"); sub.setGravity(17); sub.setTextColor(0xFF666078); root.addView(sub);
        status=new TextView(this); status.setText("● Ready"); status.setTextSize(16); status.setTextColor(0xFF27834A); status.setGravity(17); status.setPadding(0,18,0,12); root.addView(status);
        ScrollView scroll=new ScrollView(this); chat=new TextView(this); chat.setText("Kashish: नमस्ते! मैं आपकी मदद के लिए तैयार हूँ।\\n\\nTry: YouTube खोलो, समय बताओ, बैटरी कितनी है, Google पर मौसम खोजो।"); chat.setTextSize(16); chat.setTextColor(0xFF30283B); chat.setPadding(16,16,16,16); chat.setBackgroundColor(0xFFFFFFFF); scroll.addView(chat);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        input=new EditText(this); input.setSingleLine(true); input.setHint("अपना कमांड लिखें…"); root.addView(input);
        Button send=button("Send command"); send.setOnClickListener(v->runCommand(input.getText().toString())); root.addView(send);
        Button mic=button("🎙 Tap to speak"); mic.setOnClickListener(v->listen()); root.addView(mic);
        LinearLayout row=new LinearLayout(this); row.setOrientation(0);
        Button lang=button("हिंदी / English"); lang.setOnClickListener(v->{hindi=!hindi;if(tts!=null)tts.setLanguage(hindi?new Locale("hi","IN"):Locale.US);say(hindi?"हिंदी चुनी गई":"English selected");}); row.addView(lang,new LinearLayout.LayoutParams(0,-2,1));
        Button help=button("Commands"); help.setOnClickListener(v->reply("कमांड: open YouTube, open Chrome, call 9876543210, sms 9876543210 hello, search weather, time, date, battery, settings")); row.addView(help,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);
        setContentView(root);
    }
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    private void listen(){
        if(recognizer==null){reply("Speech recognition इस डिवाइस पर उपलब्ध नहीं है।");return;}
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},AUDIO_PERMISSION);return;}
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,hindi?"hi-IN":"en-US");
        try{recognizer.startListening(i);}catch(Exception e){reply("माइक शुरू नहीं हो पाया।");}
    }
    private void runCommand(String raw){
        String q=raw==null?"":raw.trim(); if(q.isEmpty())return;
        add("You: "+q);
        String s=q.toLowerCase(Locale.ROOT);
        if(s.contains("youtube")||s.contains("यूट्यूब")){reply("YouTube खोल रही हूँ।");openApp("com.google.android.youtube","https://www.youtube.com");}
        else if(s.contains("chrome")||s.contains("browser")||s.contains("ब्राउज़र")){reply("Browser खोल रही हूँ।");openApp("com.android.chrome","https://www.google.com");}
        else if(s.startsWith("call ")||s.startsWith("कॉल ")){String n=q.replaceFirst("(?i)^(call|कॉल)\\\\s*","").replaceAll("[^0-9+]","");if(n.isEmpty())reply("फोन नंबर बोलिए।");else{reply("कॉल करने से पहले नंबर जाँच लें।");startActivity(new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+n)));}}
        else if(s.startsWith("sms ")){String[] p=q.substring(4).trim().split("\\\\s+",2);if(p.length==0||!p[0].matches("[0-9+]+"))reply("पहले नंबर, फिर संदेश बोलें।");else{Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"+p[0]));if(p.length>1)i.putExtra("sms_body",p[1]);startActivity(i);}}
        else if(s.contains("time")||s.contains("समय")){reply("अभी समय है "+new SimpleDateFormat("hh:mm a",Locale.getDefault()).format(new Date()));}
        else if(s.contains("date")||s.contains("तारीख")){reply("आज "+new SimpleDateFormat("dd MMMM yyyy",Locale.getDefault()).format(new Date()));}
        else if(s.contains("battery")||s.contains("बैटरी")){BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);reply("बैटरी स्तर "+bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)+" प्रतिशत है।");}
        else if(s.contains("setting")||s.contains("सेटिंग")){reply("Settings खोल रही हूँ।");startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}
        else if(s.startsWith("search ")||s.startsWith("खोज ")){String term=q.replaceFirst("(?i)^(search|खोज)\\\\s*","");reply("Google पर खोज रही हूँ।");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(term))));}
        else{reply("मैंने सुना: "+q+". इस कमांड के लिए अभी AI कनेक्शन सेट नहीं है।");}
    }
    private void openApp(String pkg,String url){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null)startActivity(i);else startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}}
    private void add(String line){chat.append("\\n\\n"+line);}
    private void reply(String msg){add("Kashish: "+msg);say(msg);}
    private void say(String msg){if(tts!=null)tts.speak(msg,TextToSpeech.QUEUE_FLUSH,null,"kashish");}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==AUDIO_PERMISSION&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)listen();}
    @Override protected void onDestroy(){if(recognizer!=null)recognizer.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
}
